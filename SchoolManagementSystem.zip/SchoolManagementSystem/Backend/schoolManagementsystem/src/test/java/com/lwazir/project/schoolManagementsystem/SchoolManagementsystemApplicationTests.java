package com.lwazir.project.schoolManagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolManagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
