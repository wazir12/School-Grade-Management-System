package com.lwazir.project.schoolManagementsystem.model.joins.dto;

public class SubjectByCourseIdDTO {

	private String subjectName;
	
	

	public SubjectByCourseIdDTO(String subjectName) {
		super();
		this.subjectName = subjectName;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	
	
}
