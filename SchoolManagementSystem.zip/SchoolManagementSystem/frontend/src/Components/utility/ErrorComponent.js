import React , { Component } from "react";

export default class ErrorComponent extends Component{

    render(){
        return (
            <div>Error 404: Page Not Found</div>
        );
    }
   
}